package ddwu.com.mobile.mediadbtest

data class MediaDto(val id: Long, val fileName: String, val path: String)