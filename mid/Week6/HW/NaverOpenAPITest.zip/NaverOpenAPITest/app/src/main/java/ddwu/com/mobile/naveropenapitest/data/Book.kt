package ddwu.com.mobile.naveropenapitest.data

data class Book(
    var title: String?,
    var author: String?,
    var publisher: String?
)
