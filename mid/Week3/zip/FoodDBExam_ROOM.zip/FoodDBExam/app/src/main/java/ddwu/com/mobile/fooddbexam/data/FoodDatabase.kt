package ddwu.com.mobile.fooddbexam.data

abstract class FoodDatabase{

}


