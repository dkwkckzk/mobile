package ddwu.com.mobile.roomexam01

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import ddwu.com.mobile.roomexam01.data.Food
import ddwu.com.mobile.roomexam01.databinding.ListItemBinding

// 리사이클러뷰의 어댑터 - 데이터를 받아와서 각각의 아이템을 어떻게 화면에 표시할지 결정
class FoodAdapter : ListAdapter<Food, FoodAdapter.FoodViewHolder>(FoodDiffCallback()) {
    val TAG = "FoodAdapter"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val itemBinding = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(itemBinding)
    } // 뷰홀더 객체 생성

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val food = getItem(position)
        holder.itemBinding.tvItem.text = food.toString()
        holder.itemBinding.root.setOnLongClickListener{
            itemLongClickListener?.onItemLongClickListener(it, position)
            true
        } // 뷰홀더에 데이터를 바인딩 함
    }

    // 아이템뷰를 표현하고 재사용하기 위한 객체
    // 목록의 특정 위치에 있는 하나의 아이템을 나타내며, 그 아이템의 뷰참조를 유지한다. 즉, ViewHolder가 '보유'하는 것은 '뷰'라고 할 수 있다.
    // 따라서 RecydlerView가 스크롤 될 때마다 새로운 뷰를 계속 생성하는 대신 이미 생성된 ViewHolder와 그 안에 있는 뷰들을 재사용함을로써 성능 향상과 메모리 사용향 최소화 등의 이점을 얻음
    class FoodViewHolder(val itemBinding: ListItemBinding) : RecyclerView.ViewHolder(itemBinding.root)
    interface OnItemLongClickListener {
        fun onItemLongClickListener(view: View, pos: Int)
    }

    var itemLongClickListener : OnItemLongClickListener? = null

    fun setOnItemLongClickListener(listener: OnItemLongClickListener?) {
        itemLongClickListener = listener
    }

}

// DiffUtil의 콜백 - 두 개의 리스트 항목이 같은지 다른지를 판단
class FoodDiffCallback : DiffUtil.ItemCallback<Food>() {

    override fun areItemsTheSame(oldItem: Food, newItem: Food): Boolean =
        oldItem._id == newItem._id // 두 음식 객체가 동일한 항목을 나타내는지. 즉, 동일한 ID를 가진 항목인지

    override fun areContentsTheSame(oldItem: Food, newItem: Food): Boolean =
        oldItem == newItem // 두 음식 객체가 동일한 데이터(모든 필드가 동일한)를 가진 항목인지 판단.
} // ListAdapter 사용시 DiffUtil 콜백을 제공하면 어댑터가 자동으로 리스트 갱신 시 변경된 부분만 업데이트 해주어 효율적으로 작동
