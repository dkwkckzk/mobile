package ddwu.com.mobile.roomexam01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import ddwu.com.mobile.roomexam01.data.Food
import ddwu.com.mobile.roomexam01.data.FoodDao
import ddwu.com.mobile.roomexam01.data.FoodDatabase
import ddwu.com.mobile.roomexam01.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// IO dispatcher is used for database operations.
// It's not recommended to use Main dispatcher for such operations, as it can block the UI thread.
// Also, note that the Dispatchers.Main is used to update the UI after performing database operations in background.
// So, here we're using appropriate dispatchers for appropriate tasks.
// For more info on Coroutines Dispatchers: https://developer.android.com/kotlin/coroutines/coroutines-adv#main-safety

class MainActivity : AppCompatActivity() {

    val TAG = "MainActivity"

    lateinit var binding: ActivityMainBinding

    lateinit var db : FoodDatabase // Database instance
    lateinit var foodDao : FoodDao // DAO instance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            FoodDatabase::class.java,
            "food_db"
        ).build()

        foodDao = db.foodDao()

        /*RecyclerView 의 layoutManager 지정*/
        binding.foodRecyclerView.layoutManager = LinearLayoutManager(this).apply {
            orientation = LinearLayoutManager.VERTICAL
            // You can change this to HORIZONTAL if you want a horizontal layout. Default is VERTICAL.

        }

        /*샘플 데이터, DB 사용 시 DB에서 읽어온 데이터로 대체 필요*/
        val foods = listOf(
            Food(1,"된장찌개", "한국"),
            Food(2,"김치찌개", "한국"),
            Food(3,"마라탕", "중국"),
            Food(4,"훠궈", "중국"),
            Food(5,"스시", "일본"),
            Food(6,"오코노미야키", "일본")
        )

        CoroutineScope(IO).launch {
            foods.forEach { food ->
                foodDao.insertFood(food)
            }
        }


        //foodAdapter = FoodAdapter(foods)
        /*foodAdapter 에 LongClickListener 구현 및 설정*/
        val foodAdapter = FoodAdapter().apply {
            setOnItemLongClickListener(object : FoodAdapter.OnItemLongClickListener {
                override fun onItemLongClickListener(view: View, pos: Int) {
                    Log.d(TAG, "Long Click!! $pos")
                }
            })
        }

        binding.foodRecyclerView.adapter = foodAdapter

        CoroutineScope(IO).launch {  // Coroutine scope with IO dispatcher
            foodDao.getAllFoods().collect { foodsFromDB ->  // Get all foods from DB
                withContext(Dispatchers.Main) {
                    foodAdapter.submitList(foodsFromDB)  // Update adapter with new data from DB
                }
            }
        }

        binding.btnInsert.setOnClickListener{
            val food = Food(0, "새 음식", "한국")  // 새로 추가할 음식 객체 생성
            addFood(food)
        }

        binding.btnUpdate.setOnClickListener {
            val food = Food(1, "수정된 음식", "한국")  // 수정할 음식 객체 생성 (id는 기존에 있던 아이템의 id를 사용해야 합니다)
            modifyFood(food)
        }

        binding.btnDelete.setOnClickListener {
            val food = Food(1, "", "")  // 삭제할 음식 객체 생성 (id만 중요하므로 나머지 필드는 빈 문자열 등으로 설정 가능합니다)
            removeFood(food)
        }
    }

    fun addFood(food: Food) {
        CoroutineScope(IO).launch {
            foodDao.insertFood(food)  // 백그라운드 스레드에서 음식 정보 추가 수행
        }
    }

    fun modifyFood(food: Food) {
        CoroutineScope(IO).launch {
            foodDao.updateFood(food)  // 백그라운드 스레드에서 음식 정보 수정 수행
        }
    }

    fun removeFood(food: Food) {
        CoroutineScope(IO).launch {
            foodDao.deleteFood(food)  // 백그라운드 스레드에서 음식 정보 삭제 수행
        }
    }
}