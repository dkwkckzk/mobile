package ddwu.com.mobile.jsonnetworktest.network

import ddwu.com.mobile.jsonnetworktest.data.BoxOfficeRoot

interface IBoxOfficeAPIService {
//    @GET("kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.{type}")
    fun getDailyBoxOffice(
//        @Path ("type") type: String,
//        @Query ("key") key: String,
//        @Query ("targetDt") targetDate: String,
    )
//    : Call<BoxOfficeRoot>
}

