package ddwu.com.mobile.naverretrofittest.data

data class BookRoot (

)


data class Item (

)